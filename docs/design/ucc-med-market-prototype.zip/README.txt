UCC Med Market - visual-review prototype

Open review.html in a modern browser. No installation, server or account is needed.
Use the screen selector, navigation links and moon/sun theme button.
All listings, people, businesses and counts are fictional design content.
This prototype makes no API calls and cannot save, publish or contact anyone.
The PDF pack and implementation blueprint are in the repository's docs/design directory.
Sample photography: Unsplash. Never seed these examples into production.
